#!/bin/sh
echo RAN-SETUP
